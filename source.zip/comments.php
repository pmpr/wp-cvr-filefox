<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68868aed9985a             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
