<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b7aac6ed71f             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
