<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6843ea8014d33             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
