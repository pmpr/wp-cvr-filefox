<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67cf2e61c45da             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
