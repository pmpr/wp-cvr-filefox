<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169e221b5fa             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
