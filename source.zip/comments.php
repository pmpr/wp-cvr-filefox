<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68056b353953e             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
