<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             682fcb21e6584             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
