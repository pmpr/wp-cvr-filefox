<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689e5f2b6d10b             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
