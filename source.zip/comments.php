<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68821f0aaa69d             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
