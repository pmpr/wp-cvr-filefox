<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a48ec46efab             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
