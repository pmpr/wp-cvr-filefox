<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9d4b867aca             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
