<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             681a82fc5e2dd             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
