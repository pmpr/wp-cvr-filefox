<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ac858fded43             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
