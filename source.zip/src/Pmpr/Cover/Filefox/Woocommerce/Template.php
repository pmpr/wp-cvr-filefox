<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4de08a61             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Cover\Woocommerce\Template as BaseClass; use Pmpr\Cover\Filefox\Traits\CommonTrait; abstract class Template extends BaseClass { use CommonTrait; }
