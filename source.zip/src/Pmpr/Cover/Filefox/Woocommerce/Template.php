<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a868dc559             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Cover\Woocommerce\Template as BaseClass; use Pmpr\Cover\Filefox\Traits\CommonTrait; abstract class Template extends BaseClass { use CommonTrait; }
