<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bcab602aee             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Cover\Woocommerce\Template as BaseClass; use Pmpr\Cover\Filefox\Traits\CommonTrait; abstract class Template extends BaseClass { use CommonTrait; }
