<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6838de07b7866             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Asset extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('wp_print_styles', [$this, 'mscuiiokkeauiuaw'])->qcsmikeggeemccuu('wp_enqueue_scripts', [$this, 'moussguuiqqkqaau'], 100); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('woocommerce_enqueue_styles', '__return_empty_array'); } public function mscuiiokkeauiuaw() { $this->uwkmaywceaaaigwo()->usugyumcgeaaowsi()->ciuuyygmkuwgoiki('woocommerce-inline', 'after', ''); } public function moussguuiqqkqaau() { $geoqacegumkcaskk = $this->uwkmaywceaaaigwo()->usugyumcgeaaowsi(); $geoqacegumkcaskk->qkyugogwegiuiime('select2'); $geoqacegumkcaskk->iqmcmgkyssqgoqok('select2'); $geoqacegumkcaskk->saisougiwmauksiy('select2'); $geoqacegumkcaskk->cawwmsmyseesuyee('select2'); $geoqacegumkcaskk->saisougiwmauksiy('selectWoo'); $geoqacegumkcaskk->cawwmsmyseesuyee('selectWoo'); } }
