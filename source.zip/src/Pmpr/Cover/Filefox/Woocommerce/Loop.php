<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4de08a61             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\x6f\x6f\x63\x6f\x6d\155\145\162\143\145\137\x70\x72\x6f\144\165\143\164\137\x6c\157\157\160\137\164\x69\x74\x6c\x65\137\143\154\141\163\x73\145\x73", [$this, "\x61\167\157\155\153\161\x71\x75\161\x77\x6b\171\x6d\x67\167\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\x20\150\63\40\x6d\142\x2d\x32\x20\154\151\x6e\145\x2d\154\151\155\x69\x74\x20\154\x69\x6e\x65\x2d\154\151\x6d\x69\x74\x2d\x31"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\167\157\157\x63\157\155\155\x65\x72\x63\x65\55\160\x61\147\151\x6e\141\x74\x69\x6f\x6e" => ["\143\154\141\163\x73" => "\144\x2d\146\x6c\145\170\40\x6a\165\163\164\151\146\x79\55\143\157\156\x74\x65\x6e\164\55\143\145\156\164\145\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
