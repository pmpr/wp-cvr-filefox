<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bcab602aee             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\157\157\x63\157\155\155\145\x72\x63\x65\137\160\162\x6f\x64\x75\x63\164\x5f\154\157\x6f\x70\x5f\x74\x69\x74\x6c\145\137\x63\154\141\163\163\145\163", [$this, "\141\167\157\x6d\x6b\161\x71\165\x71\167\153\171\x6d\x67\167\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\x20\x68\63\x20\x6d\x62\x2d\62\x20\154\x69\156\x65\55\x6c\151\x6d\151\x74\x20\154\151\x6e\145\x2d\154\x69\x6d\151\164\x2d\61"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\167\x6f\x6f\x63\157\155\x6d\x65\x72\x63\145\x2d\x70\x61\147\151\156\141\164\151\x6f\x6e" => ["\x63\x6c\x61\163\163" => "\x64\55\x66\154\x65\170\x20\152\x75\163\164\151\146\x79\x2d\x63\157\156\x74\x65\156\x74\55\x63\145\156\164\x65\x72"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
