<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b7aac6ed71f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('woocommerce_product_loop_title_classes', [$this, 'awomkqquqwkymgwi']); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw} h3 mb-2 line-limit line-limit-1"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ['.woocommerce-pagination' => ['class' => 'd-flex justify-content-center']]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
