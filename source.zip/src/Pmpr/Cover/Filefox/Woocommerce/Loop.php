<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a886ed4b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\x2e\167\x6f\157\x63\157\155\x6d\x65\x72\143\145\x2d\160\x61\147\x69\156\x61\164\151\x6f\x6e" => ["\143\154\141\163\x73" => "\x64\55\146\x6c\145\170\40\152\165\x73\x74\x69\146\x79\55\143\x6f\156\x74\x65\x6e\x74\55\143\145\156\x74\145\x72"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
