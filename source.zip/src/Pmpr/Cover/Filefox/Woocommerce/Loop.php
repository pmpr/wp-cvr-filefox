<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbeaaf010d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\157\157\143\157\155\x6d\145\162\x63\x65\137\x70\162\x6f\x64\x75\x63\164\137\x6c\157\x6f\160\x5f\164\151\164\x6c\145\137\x63\154\x61\163\x73\145\163", [$this, "\x61\x77\x6f\x6d\153\161\x71\x75\161\167\x6b\171\x6d\147\167\151"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\x20\x68\x33\40\155\x62\55\62\40\x6c\x69\x6e\145\x2d\x6c\151\155\x69\164\x20\x6c\x69\x6e\145\55\x6c\x69\x6d\151\164\55\61"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\167\157\x6f\x63\157\x6d\x6d\145\162\x63\145\x2d\x70\x61\x67\x69\x6e\x61\x74\x69\157\156" => ["\143\154\141\x73\163" => "\x64\55\146\154\145\x78\x20\x6a\165\163\164\151\146\171\x2d\x63\157\x6e\164\145\156\x74\x2d\x63\x65\x6e\164\145\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
