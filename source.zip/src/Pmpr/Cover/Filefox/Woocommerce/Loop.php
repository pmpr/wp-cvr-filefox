<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67915234b5a7e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\157\157\x63\157\x6d\155\x65\x72\143\x65\x5f\160\162\x6f\144\165\143\x74\137\154\157\157\x70\x5f\164\x69\x74\x6c\x65\x5f\143\154\x61\163\163\145\x73", [$this, "\x61\167\x6f\x6d\153\x71\x71\165\161\x77\x6b\171\x6d\x67\x77\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\150\63\40\155\142\55\x32\x20\x6c\151\156\x65\x2d\x6c\x69\155\x69\164\40\x6c\x69\156\x65\x2d\154\x69\155\x69\164\x2d\61"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\x77\x6f\157\x63\x6f\x6d\155\145\x72\143\145\x2d\160\141\x67\x69\156\141\164\151\x6f\x6e" => ["\x63\x6c\x61\163\163" => "\x64\55\146\x6c\145\x78\40\x6a\x75\x73\164\x69\146\171\55\x63\157\x6e\164\x65\156\164\x2d\x63\145\x6e\164\x65\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
