<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc12edef6a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\157\157\143\x6f\x6d\x6d\145\162\x63\145\x5f\160\162\x6f\144\165\143\164\x5f\154\x6f\157\x70\x5f\164\151\x74\x6c\145\x5f\x63\154\x61\x73\x73\x65\x73", [$this, "\x61\x77\157\155\x6b\161\161\165\x71\167\x6b\x79\155\x67\167\151"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\150\63\x20\155\x62\55\x32\x20\x6c\151\156\x65\55\154\x69\x6d\151\x74\40\154\x69\x6e\x65\55\154\x69\155\151\x74\55\x31"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\x2e\167\157\157\x63\x6f\155\x6d\x65\162\x63\145\55\x70\141\x67\151\156\141\164\x69\157\156" => ["\x63\154\x61\x73\x73" => "\144\55\x66\x6c\145\x78\x20\x6a\x75\163\x74\x69\146\x79\x2d\143\x6f\x6e\164\x65\x6e\x74\55\143\145\156\x74\145\x72"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
