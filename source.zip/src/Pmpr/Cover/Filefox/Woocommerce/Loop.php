<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbf4e071b1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\157\157\x63\x6f\155\x6d\x65\x72\143\x65\x5f\160\x72\x6f\144\x75\143\x74\137\x6c\x6f\157\x70\x5f\164\151\x74\154\x65\137\143\x6c\141\163\163\145\163", [$this, "\141\167\157\155\153\x71\x71\165\x71\x77\x6b\171\155\x67\x77\151"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\150\x33\x20\155\x62\x2d\x32\x20\x6c\x69\x6e\x65\55\x6c\151\x6d\151\164\x20\x6c\151\156\x65\x2d\154\151\x6d\151\x74\55\61"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\x2e\167\x6f\157\143\x6f\x6d\155\145\162\143\x65\55\x70\141\147\151\x6e\141\x74\x69\x6f\x6e" => ["\x63\154\x61\x73\163" => "\144\55\x66\x6c\x65\x78\40\x6a\x75\x73\164\x69\x66\171\55\x63\157\x6e\x74\x65\x6e\164\55\143\x65\x6e\164\145\x72"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
