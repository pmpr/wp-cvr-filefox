<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678030ca66a8e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\x6f\x63\x6f\155\x6d\145\162\x63\145\137\x70\162\x6f\144\x75\x63\164\137\x6c\x6f\x6f\160\137\x74\x69\x74\x6c\x65\x5f\x63\x6c\141\x73\163\x65\x73", [$this, "\x61\x77\x6f\x6d\153\161\161\x75\x71\167\x6b\171\155\x67\x77\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\150\63\x20\x6d\142\55\x32\40\154\x69\156\x65\55\x6c\151\x6d\151\164\x20\154\x69\x6e\145\x2d\x6c\151\155\151\164\55\x31"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\167\x6f\157\143\x6f\155\155\145\162\143\145\x2d\160\141\147\151\x6e\x61\164\x69\157\x6e" => ["\x63\x6c\141\163\x73" => "\144\x2d\x66\x6c\145\170\40\x6a\165\163\x74\x69\x66\171\55\143\157\156\164\145\156\x74\x2d\x63\145\x6e\164\x65\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
