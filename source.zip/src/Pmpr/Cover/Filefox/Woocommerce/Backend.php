<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebebf1b4e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\151\156\x5f\x69\x6e\151\164", [$this, "\171\x65\x79\151\147\165\171\145\147\155\x6d\171\x75\x73\145\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\x61\x74\145\162\151\x61\x6c\x5f\x6d\145\x67\x61\155\145\156\165\137\146\151\145\154\x64\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\120\154\165\x72\x61\x6c\x20\116\141\x6d\145", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\x6d\x61\164\x65\x72\151\141\x6c")->register(); } }
