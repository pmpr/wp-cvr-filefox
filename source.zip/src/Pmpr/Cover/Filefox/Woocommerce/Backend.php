<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbf4e071b1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\151\x6e\x5f\x69\x6e\151\164", [$this, "\x79\x65\x79\x69\147\x75\x79\145\147\x6d\155\171\x75\x73\x65\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\x6d\x61\164\x65\162\x69\141\154\137\155\145\147\x61\155\145\156\x75\x5f\146\x69\145\154\x64\x73")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\154\x75\x72\x61\154\x20\116\x61\x6d\x65", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\x61\164\145\x72\151\141\154")->register(); } }
