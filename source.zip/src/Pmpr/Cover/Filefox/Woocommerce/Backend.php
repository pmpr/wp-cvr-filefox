<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661da2bc3684a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\151\156\x5f\151\x6e\x69\x74", [$this, "\x79\x65\x79\151\x67\165\x79\x65\x67\x6d\x6d\x79\x75\163\x65\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\x6d\141\x74\x65\x72\x69\x61\154\x5f\155\145\147\x61\x6d\x65\x6e\x75\x5f\146\x69\145\154\x64\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(self::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\x6c\x75\x72\x61\x6c\x20\x4e\141\155\x65", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\141\x74\x65\x72\151\141\154")->register(); } }
