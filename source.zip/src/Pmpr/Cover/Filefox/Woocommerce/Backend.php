<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678030ca66a8e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\x6e\x5f\151\x6e\151\164", [$this, "\x79\x65\171\x69\x67\165\x79\145\x67\x6d\155\x79\165\163\x65\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\141\164\145\162\151\141\154\x5f\155\x65\147\141\155\145\156\x75\x5f\146\151\x65\x6c\x64\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\x6c\x75\x72\141\x6c\40\116\x61\155\x65", PR__CVR__FILEFOX)))->auoaeeuwaqswggqg("\x6d\141\x74\x65\162\x69\141\154")->register(); } }
