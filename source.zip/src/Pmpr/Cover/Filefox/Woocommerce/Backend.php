<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b65bd86d7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\x6e\137\x69\x6e\151\x74", [$this, "\171\x65\171\151\x67\165\x79\145\147\x6d\x6d\171\x75\163\x65\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\x6d\x61\164\x65\162\151\x61\x6c\137\x6d\x65\x67\x61\x6d\x65\x6e\x75\137\x66\x69\x65\x6c\144\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(self::mmieaueggwwaokig)->gswweykyogmsyawy(__("\120\154\x75\x72\x61\x6c\x20\116\141\x6d\x65", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\x6d\141\x74\145\x72\151\141\x6c")->register(); } }
