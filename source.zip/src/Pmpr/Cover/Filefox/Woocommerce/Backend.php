<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400881d567             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\x69\156\137\x69\x6e\x69\x74", [$this, "\171\145\x79\x69\x67\165\171\x65\147\x6d\155\x79\x75\x73\145\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\x6d\x61\x74\x65\x72\x69\141\154\x5f\x6d\x65\x67\141\x6d\145\156\165\x5f\x66\151\145\154\x64\x73")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(self::mmieaueggwwaokig)->gswweykyogmsyawy(__("\120\154\165\162\141\154\40\x4e\x61\x6d\x65", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\x6d\141\164\x65\x72\x69\x61\154")->register(); } }
