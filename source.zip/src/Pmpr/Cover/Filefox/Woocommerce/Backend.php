<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11456bfce             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\x69\156\137\x69\156\151\x74", [$this, "\x79\145\171\151\147\165\171\145\x67\155\x6d\x79\165\x73\x65\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\141\x74\145\162\x69\141\x6c\137\155\x65\147\x61\155\145\156\x75\137\146\151\145\154\x64\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\120\x6c\165\x72\141\x6c\40\x4e\x61\x6d\x65", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\x6d\x61\x74\145\162\151\x61\x6c")->register(); } }
