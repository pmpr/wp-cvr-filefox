<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbeaaf010d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\156\137\151\156\151\x74", [$this, "\x79\x65\x79\x69\147\x75\171\x65\147\155\155\171\165\163\x65\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\141\x74\x65\x72\151\141\x6c\137\155\145\147\141\155\145\x6e\x75\x5f\x66\151\145\154\144\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\120\x6c\165\x72\x61\154\40\116\141\155\145", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\x6d\141\x74\145\x72\x69\141\154")->register(); } }
