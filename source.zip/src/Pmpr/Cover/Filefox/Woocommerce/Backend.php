<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf78515951             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\156\x5f\151\x6e\x69\x74", [$this, "\x79\145\171\151\x67\165\x79\x65\x67\155\155\171\165\x73\145\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\x6d\x61\164\x65\162\x69\x61\x6c\x5f\x6d\x65\x67\x61\x6d\145\x6e\165\x5f\x66\151\145\x6c\x64\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(self::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\x6c\165\162\141\154\40\116\x61\155\x65", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\141\164\145\x72\x69\141\x6c")->register(); } }
