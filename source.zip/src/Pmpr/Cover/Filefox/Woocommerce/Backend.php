<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc12edef6a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\151\x6e\x5f\151\x6e\x69\x74", [$this, "\x79\x65\x79\x69\x67\165\171\x65\x67\x6d\155\x79\165\x73\x65\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\x61\x74\x65\x72\151\141\154\137\x6d\x65\x67\141\x6d\x65\x6e\x75\x5f\x66\x69\x65\x6c\144\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\154\165\162\x61\x6c\40\116\x61\155\145", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\x61\x74\145\162\151\141\x6c")->register(); } }
