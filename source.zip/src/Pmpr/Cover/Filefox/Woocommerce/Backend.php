<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85b7f9cf             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\156\x5f\151\x6e\x69\164", [$this, "\171\x65\171\151\x67\165\171\x65\x67\x6d\155\171\x75\x73\145\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\x6d\x61\164\x65\162\x69\x61\154\137\x6d\x65\x67\x61\x6d\145\x6e\x75\137\146\x69\x65\154\144\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\120\x6c\165\x72\x61\154\40\116\x61\x6d\145", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\x6d\141\164\x65\162\151\141\154")->register(); } }
