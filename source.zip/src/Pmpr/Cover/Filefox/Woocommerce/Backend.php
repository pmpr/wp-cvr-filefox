<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707be02c6f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\x69\156\137\x69\x6e\151\x74", [$this, "\x79\145\x79\x69\x67\x75\171\x65\147\x6d\155\171\165\x73\x65\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\x6d\x61\164\145\162\x69\141\x6c\x5f\x6d\145\x67\x61\x6d\x65\x6e\165\137\x66\151\145\154\144\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(self::mmieaueggwwaokig)->gswweykyogmsyawy(__("\120\154\x75\x72\141\154\40\x4e\141\x6d\145", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\141\164\x65\x72\151\x61\154")->register(); } }
