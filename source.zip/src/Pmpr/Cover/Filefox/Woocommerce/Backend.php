<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a886ed4b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\151\156\137\151\x6e\151\x74", [$this, "\x79\x65\171\151\x67\x75\171\145\147\x6d\155\171\165\x73\x65\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\141\164\145\x72\x69\x61\x6c\x5f\155\x65\147\x61\x6d\x65\156\165\137\146\151\145\x6c\x64\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\x6c\x75\162\x61\154\x20\x4e\x61\155\x65", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\x61\x74\145\x72\151\x61\154")->register(); } }
