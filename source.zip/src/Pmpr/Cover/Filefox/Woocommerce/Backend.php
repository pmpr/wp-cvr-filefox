<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4de08a61             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\x69\156\x5f\151\156\151\164", [$this, "\171\x65\x79\x69\x67\165\x79\x65\147\x6d\x6d\x79\x75\163\x65\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\x61\164\x65\x72\x69\x61\154\137\155\145\147\x61\x6d\x65\x6e\165\137\146\x69\x65\x6c\x64\x73")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\154\x75\x72\141\x6c\40\116\x61\x6d\145", PR__CVR__FILEFOX)))->auoaeeuwaqswggqg("\155\141\164\145\x72\x69\141\154")->register(); } }
