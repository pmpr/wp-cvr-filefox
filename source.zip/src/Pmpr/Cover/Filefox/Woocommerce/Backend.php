<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bcab602aee             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\151\x6e\x5f\151\x6e\x69\164", [$this, "\171\145\x79\x69\x67\x75\171\x65\147\x6d\x6d\x79\165\163\x65\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\x6d\141\164\145\x72\x69\141\x6c\x5f\x6d\145\147\141\x6d\x65\x6e\165\137\146\x69\145\154\144\x73")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\x6c\165\162\x61\x6c\40\116\x61\155\x65", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\x61\x74\x65\x72\x69\141\x6c")->register(); } }
