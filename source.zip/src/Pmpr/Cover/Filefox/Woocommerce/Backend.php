<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67915234b5a7e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\151\x6e\137\151\x6e\x69\164", [$this, "\171\x65\171\x69\147\x75\171\x65\147\155\x6d\x79\x75\x73\145\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\x61\164\x65\162\151\141\154\x5f\x6d\x65\147\141\155\145\156\165\137\x66\x69\x65\x6c\x64\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\x6c\165\162\141\154\40\116\141\155\x65", PR__CVR__FILEFOX)))->auoaeeuwaqswggqg("\155\141\x74\x65\162\151\x61\154")->register(); } }
