<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb569c6a791             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\x69\156\x5f\151\x6e\151\164", [$this, "\171\145\171\151\x67\x75\x79\145\x67\x6d\x6d\x79\x75\x73\145\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\x61\164\145\162\151\141\154\x5f\155\x65\147\141\155\x65\x6e\165\137\146\151\x65\x6c\144\x73")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(self::mmieaueggwwaokig)->gswweykyogmsyawy(__("\120\154\x75\x72\x61\154\x20\116\141\x6d\145", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\x6d\x61\164\x65\162\x69\x61\x6c")->register(); } }
