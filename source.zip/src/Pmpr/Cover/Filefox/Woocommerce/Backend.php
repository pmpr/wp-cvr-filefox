<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a868dc559             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\151\156\137\151\x6e\x69\164", [$this, "\171\145\171\x69\147\x75\x79\x65\147\x6d\155\171\165\x73\x65\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\141\x74\x65\162\151\141\x6c\137\155\x65\x67\141\155\145\x6e\x75\x5f\146\151\145\x6c\144\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(self::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\154\x75\162\141\154\x20\x4e\x61\x6d\x65", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\x61\x74\x65\162\x69\141\154")->register(); } }
