<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e580c0d709a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Cover\Filefox\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
