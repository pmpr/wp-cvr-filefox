<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb569c6a791             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x70\137\x66\x6f\157\x74\x65\x72", [$this, "\x79\x67\153\143\x65\153\x71\x6b\145\151\x79\145\x79\163\161\x69"])->qcsmikeggeemccuu("\x77\x69\144\x67\x65\x74\163\x5f\x69\156\151\164", [$this, "\171\x6d\x61\x79\167\x63\143\141\151\163\x63\163\x6d\163\x69\x6b"]); $this->waqewsckuayqguos("\162\145\x6e\144\145\162\x5f\146\x6f\x6f\x74\x65\x72", [$this, "\162\x65\x6e\x64\145\162"])->waqewsckuayqguos("\162\x65\x6e\x64\145\162\x5f\163\x69\x67\156\x61\x74\x75\162\145", [$this, "\x61\171\x6d\161\x73\153\155\x77\x73\165\x77\157\x63\x73\x6d\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\x6e\x64\x65\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
