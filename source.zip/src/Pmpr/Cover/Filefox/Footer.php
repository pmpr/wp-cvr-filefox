<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67915234b5a7e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x70\x5f\146\x6f\x6f\164\145\x72", [$this, "\x79\x67\153\143\x65\x6b\x71\153\145\151\171\x65\x79\x73\161\151"])->qcsmikeggeemccuu("\167\151\144\x67\145\x74\x73\137\151\156\151\164", [$this, "\171\x6d\x61\x79\167\x63\x63\141\x69\163\x63\163\155\x73\x69\x6b"]); $this->waqewsckuayqguos("\162\145\x6e\x64\145\162\x5f\146\157\157\164\145\x72", [$this, "\162\x65\156\x64\x65\162"])->waqewsckuayqguos("\x72\145\x6e\144\145\x72\137\x73\x69\x67\x6e\141\x74\165\x72\145", [$this, "\141\x79\x6d\161\x73\x6b\x6d\167\x73\x75\167\x6f\x63\163\x6d\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\156\144\145\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
