<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf78515951             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x70\x5f\146\x6f\x6f\x74\145\162", [$this, "\171\x67\153\143\x65\153\x71\153\x65\151\171\x65\x79\x73\x71\x69"])->qcsmikeggeemccuu("\x77\x69\x64\147\x65\x74\163\x5f\x69\x6e\151\x74", [$this, "\171\x6d\x61\171\167\143\x63\141\151\163\x63\x73\x6d\x73\x69\153"]); $this->waqewsckuayqguos("\162\x65\156\x64\145\162\137\x66\157\157\x74\145\162", [$this, "\162\145\156\144\145\x72"])->waqewsckuayqguos("\x72\x65\156\x64\x65\x72\x5f\163\x69\x67\156\x61\x74\165\162\x65", [$this, "\141\171\155\x71\163\x6b\155\x77\x73\x75\167\x6f\x63\163\x6d\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\156\x64\x65\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
