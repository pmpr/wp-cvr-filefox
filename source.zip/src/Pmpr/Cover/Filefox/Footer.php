<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbeaaf010d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160\137\x66\157\157\164\x65\162", [$this, "\x79\147\x6b\143\x65\153\x71\153\145\x69\171\x65\x79\x73\x71\151"])->qcsmikeggeemccuu("\x77\x69\x64\147\x65\164\x73\x5f\151\156\x69\x74", [$this, "\171\x6d\x61\x79\x77\143\x63\x61\151\x73\143\x73\155\x73\x69\153"]); $this->waqewsckuayqguos("\x72\145\x6e\144\145\x72\137\x66\x6f\x6f\164\145\162", [$this, "\162\x65\x6e\144\x65\x72"])->waqewsckuayqguos("\162\145\x6e\144\x65\x72\x5f\x73\x69\147\156\x61\x74\x75\x72\x65", [$this, "\141\171\x6d\161\163\x6b\155\x77\163\x75\x77\x6f\143\x73\x6d\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\x6e\x64\145\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
