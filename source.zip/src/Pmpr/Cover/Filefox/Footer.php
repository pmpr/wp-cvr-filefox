<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b65bd86d7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\160\x5f\146\157\157\x74\x65\162", [$this, "\x79\x67\153\143\x65\x6b\x71\153\x65\151\x79\x65\171\x73\x71\x69"])->qcsmikeggeemccuu("\167\151\144\147\145\x74\163\137\151\x6e\151\164", [$this, "\171\x6d\x61\171\x77\143\143\141\x69\163\x63\x73\x6d\x73\151\153"]); $this->waqewsckuayqguos("\x72\x65\156\x64\x65\x72\137\146\x6f\x6f\164\145\x72", [$this, "\x72\x65\156\144\145\x72"])->waqewsckuayqguos("\x72\x65\x6e\144\x65\162\137\163\x69\147\x6e\141\x74\x75\x72\x65", [$this, "\141\x79\155\x71\x73\153\155\167\163\165\167\x6f\143\163\x6d\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\x6e\144\145\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
