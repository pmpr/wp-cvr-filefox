<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400881d567             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160\x5f\x66\x6f\x6f\164\145\x72", [$this, "\171\x67\x6b\143\x65\153\x71\153\x65\151\x79\145\x79\163\161\x69"])->qcsmikeggeemccuu("\x77\151\144\147\145\164\x73\x5f\x69\x6e\x69\x74", [$this, "\171\x6d\x61\x79\167\x63\x63\141\x69\x73\143\163\155\x73\151\153"]); $this->waqewsckuayqguos("\x72\x65\x6e\144\x65\162\x5f\146\157\157\x74\145\162", [$this, "\162\145\156\144\x65\162"])->waqewsckuayqguos("\x72\145\x6e\x64\x65\x72\137\163\151\147\x6e\x61\164\x75\162\145", [$this, "\x61\171\x6d\x71\x73\153\x6d\167\x73\165\167\x6f\x63\163\155\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\x6e\x64\x65\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
