<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707be02c6f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\160\137\x66\157\157\x74\x65\x72", [$this, "\x79\x67\x6b\143\145\153\161\153\145\x69\171\x65\x79\x73\x71\151"])->qcsmikeggeemccuu("\167\x69\144\147\x65\164\163\x5f\x69\x6e\151\x74", [$this, "\x79\155\141\x79\x77\143\143\x61\151\163\143\163\x6d\163\x69\x6b"]); $this->waqewsckuayqguos("\x72\x65\x6e\x64\x65\x72\x5f\146\x6f\157\164\x65\x72", [$this, "\x72\145\x6e\x64\145\162"])->waqewsckuayqguos("\x72\145\156\x64\x65\162\137\163\151\x67\x6e\141\164\x75\162\x65", [$this, "\141\171\x6d\161\x73\153\155\x77\163\x75\167\x6f\143\x73\155\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\156\144\x65\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
