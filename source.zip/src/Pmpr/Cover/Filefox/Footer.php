<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc12edef6a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\160\x5f\146\x6f\157\164\145\x72", [$this, "\x79\x67\153\x63\x65\x6b\x71\153\x65\151\171\145\171\163\161\x69"])->qcsmikeggeemccuu("\167\x69\x64\147\x65\164\163\x5f\151\156\x69\x74", [$this, "\171\x6d\x61\x79\167\143\x63\x61\151\163\x63\163\x6d\163\x69\153"]); $this->waqewsckuayqguos("\x72\145\x6e\144\x65\x72\137\x66\x6f\157\164\x65\162", [$this, "\x72\x65\x6e\x64\x65\x72"])->waqewsckuayqguos("\x72\x65\156\144\145\162\x5f\163\151\x67\x6e\141\164\165\x72\145", [$this, "\141\x79\155\x71\x73\153\155\167\x73\165\167\157\x63\x73\x6d\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\x6e\x64\145\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
