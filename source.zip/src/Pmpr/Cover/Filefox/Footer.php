<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bcab602aee             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\x70\x5f\146\157\157\x74\145\162", [$this, "\x79\x67\153\x63\x65\153\x71\x6b\145\151\171\x65\x79\163\161\x69"])->qcsmikeggeemccuu("\167\x69\x64\x67\x65\x74\163\x5f\x69\156\x69\164", [$this, "\x79\155\x61\x79\x77\143\x63\141\x69\163\x63\x73\155\163\151\153"]); $this->waqewsckuayqguos("\162\x65\x6e\144\145\162\137\146\x6f\x6f\164\x65\x72", [$this, "\x72\145\156\x64\x65\162"])->waqewsckuayqguos("\x72\x65\x6e\x64\x65\x72\x5f\x73\x69\x67\x6e\141\164\x75\x72\145", [$this, "\x61\x79\x6d\x71\x73\153\x6d\x77\163\x75\x77\x6f\x63\x73\155\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\156\x64\x65\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
