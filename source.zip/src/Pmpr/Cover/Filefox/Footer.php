<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661da2bc3684a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160\x5f\x66\157\157\x74\145\x72", [$this, "\x79\x67\x6b\143\x65\153\x71\x6b\x65\151\x79\x65\171\163\161\x69"])->qcsmikeggeemccuu("\x77\x69\x64\x67\145\164\163\x5f\151\x6e\x69\x74", [$this, "\x79\x6d\x61\x79\x77\x63\143\141\151\163\143\x73\x6d\163\151\x6b"]); $this->waqewsckuayqguos("\162\x65\156\x64\145\x72\137\146\x6f\x6f\164\x65\x72", [$this, "\x72\145\156\144\145\x72"])->waqewsckuayqguos("\162\145\156\x64\x65\162\137\163\x69\x67\x6e\x61\164\165\162\x65", [$this, "\141\171\155\161\163\x6b\155\x77\163\165\x77\x6f\143\163\155\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\x6e\x64\145\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
