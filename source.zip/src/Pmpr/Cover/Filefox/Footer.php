<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11456bfce             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\160\137\146\x6f\157\164\x65\x72", [$this, "\171\x67\x6b\143\x65\x6b\161\153\145\x69\171\145\x79\x73\161\151"])->qcsmikeggeemccuu("\x77\151\144\x67\x65\x74\x73\x5f\151\x6e\x69\164", [$this, "\x79\x6d\x61\171\x77\x63\143\141\151\x73\143\163\x6d\x73\x69\153"]); $this->waqewsckuayqguos("\162\145\x6e\x64\x65\162\137\146\157\x6f\164\145\162", [$this, "\x72\145\156\144\x65\162"])->waqewsckuayqguos("\x72\145\156\x64\x65\x72\137\163\x69\x67\x6e\141\164\165\162\x65", [$this, "\141\171\155\x71\163\153\155\x77\163\x75\x77\x6f\x63\x73\x6d\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\156\x64\x65\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
