<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             682fcb21e6584             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('wp_footer', [$this, 'ocsioqkqegkwuqge'])->qcsmikeggeemccuu('widgets_init', [$this, 'ymaywccaiscsmsik']); $this->waqewsckuayqguos('render_footer', [$this, 'render'])->waqewsckuayqguos('render_signature', [$this, 'aymqskmwsuwocsmk']); } public function render() { echo $this->iuygowkemiiwqmiw('index'); } public function ocsioqkqegkwuqge() { $this->ygkcekqkeiyeysqi(); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
