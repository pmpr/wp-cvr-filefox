<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbf4e071b1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\160\x5f\146\x6f\x6f\164\145\x72", [$this, "\x79\x67\153\143\145\x6b\x71\153\145\x69\x79\x65\x79\163\x71\x69"])->qcsmikeggeemccuu("\x77\151\144\147\x65\x74\163\x5f\x69\x6e\x69\164", [$this, "\x79\155\141\171\x77\x63\x63\x61\151\x73\x63\163\x6d\163\151\x6b"]); $this->waqewsckuayqguos("\x72\145\156\x64\145\x72\x5f\146\157\157\164\x65\162", [$this, "\162\x65\156\x64\x65\x72"])->waqewsckuayqguos("\x72\x65\156\144\x65\x72\137\163\x69\147\156\x61\164\165\x72\x65", [$this, "\x61\x79\x6d\161\x73\x6b\155\167\163\x75\167\x6f\143\163\155\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\156\144\145\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
