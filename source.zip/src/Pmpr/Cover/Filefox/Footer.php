<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a868dc559             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\x70\137\x66\x6f\x6f\x74\x65\x72", [$this, "\171\x67\x6b\x63\x65\x6b\161\153\x65\151\x79\x65\171\x73\x71\151"])->qcsmikeggeemccuu("\x77\151\144\147\145\164\163\137\x69\x6e\151\164", [$this, "\171\x6d\x61\171\167\143\x63\141\x69\163\143\x73\x6d\x73\x69\x6b"]); $this->waqewsckuayqguos("\162\145\x6e\x64\x65\x72\x5f\x66\157\157\164\145\x72", [$this, "\x72\x65\x6e\x64\x65\x72"])->waqewsckuayqguos("\162\x65\x6e\144\x65\162\x5f\163\151\x67\x6e\x61\x74\165\x72\145", [$this, "\141\171\155\161\163\153\x6d\167\x73\x75\x77\157\x63\x73\155\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\x6e\144\145\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
