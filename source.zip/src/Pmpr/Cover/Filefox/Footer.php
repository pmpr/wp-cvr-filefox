<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a886ed4b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160\137\x66\x6f\157\x74\145\x72", [$this, "\171\147\153\143\x65\153\x71\x6b\145\151\171\x65\171\x73\x71\x69"])->qcsmikeggeemccuu("\167\151\144\147\x65\164\163\137\x69\x6e\x69\x74", [$this, "\x79\x6d\141\x79\x77\x63\143\141\x69\x73\x63\x73\155\x73\151\x6b"]); $this->waqewsckuayqguos("\162\145\156\144\x65\162\x5f\x66\x6f\157\x74\145\x72", [$this, "\x72\145\x6e\x64\x65\162"])->waqewsckuayqguos("\x72\145\x6e\144\x65\162\137\163\151\x67\x6e\141\164\x75\x72\x65", [$this, "\141\171\155\x71\x73\153\155\167\163\x75\167\157\x63\x73\x6d\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\x6e\144\x65\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
