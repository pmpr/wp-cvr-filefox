<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85b7f9cf             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x70\x5f\x66\157\157\x74\145\162", [$this, "\x79\x67\153\143\x65\x6b\x71\153\x65\151\171\x65\171\163\x71\151"])->qcsmikeggeemccuu("\167\151\144\147\145\164\163\x5f\x69\156\x69\x74", [$this, "\x79\x6d\141\171\167\x63\143\x61\151\163\x63\x73\x6d\163\151\153"]); $this->waqewsckuayqguos("\x72\145\x6e\x64\x65\x72\137\146\x6f\157\x74\145\162", [$this, "\x72\145\x6e\144\x65\162"])->waqewsckuayqguos("\x72\145\156\144\x65\162\137\x73\x69\147\x6e\141\164\165\162\145", [$this, "\x61\171\x6d\161\x73\x6b\155\x77\x73\165\167\x6f\143\x73\x6d\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\x6e\x64\145\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
