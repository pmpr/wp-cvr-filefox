<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebebf1b4e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x70\x5f\146\x6f\157\x74\145\162", [$this, "\x79\x67\153\x63\145\153\x71\153\145\x69\171\145\171\163\161\151"])->qcsmikeggeemccuu("\x77\151\144\x67\145\164\163\137\151\156\151\164", [$this, "\x79\x6d\141\171\167\143\143\x61\x69\x73\143\163\x6d\163\151\153"]); $this->waqewsckuayqguos("\x72\x65\x6e\x64\x65\x72\x5f\x66\x6f\157\164\145\x72", [$this, "\x72\x65\x6e\144\x65\162"])->waqewsckuayqguos("\162\x65\156\144\x65\x72\137\x73\151\x67\x6e\x61\164\165\x72\145", [$this, "\141\x79\x6d\x71\x73\x6b\x6d\x77\x73\165\x77\157\143\163\155\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\x6e\144\x65\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
