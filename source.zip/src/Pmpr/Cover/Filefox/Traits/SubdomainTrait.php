<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e598cfbd21a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; trait SubdomainTrait { public function aycessgueogkawag() { $mksyucucyswaukig = $this->ocksiywmkyaqseou('url_structure_get_subdomain_object', null); return $mksyucucyswaukig && Constants::oeeqisiiqoswqqmy === $this->caokeucsksukesyo()->kckogqkiycqeumoa()->yyoeeseewqmmyaee($mksyucucyswaukig) ? $mksyucucyswaukig : null; } }
