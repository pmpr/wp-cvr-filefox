<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11456bfce             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page; class About extends Common { public function __construct() { $this->slug = "\x61\142\157\165\x74"; $this->isPrivate = false; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x41\142\x6f\165\x74", PR__CVR__FILEFOX); } }
