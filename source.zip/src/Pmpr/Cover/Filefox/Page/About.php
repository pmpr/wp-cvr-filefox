<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf78515951             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page; class About extends Common { public function __construct() { $this->slug = "\141\x62\x6f\165\x74"; $this->isPrivate = false; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\101\142\157\165\164", PR__CVR__FILEFOX); } }
