<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85b7f9cf             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page; class About extends Common { public function __construct() { $this->slug = "\x61\142\x6f\165\x74"; $this->isPrivate = false; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\101\x62\x6f\165\164", PR__CVR__FILEFOX); } }
