<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b65bd86d7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page; class About extends Common { public function __construct() { $this->slug = "\x61\142\157\165\x74"; $this->isPrivate = false; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\101\142\x6f\165\x74", PR__CVR__FILEFOX); } }
