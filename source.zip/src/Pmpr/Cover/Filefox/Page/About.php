<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb569c6a791             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page; class About extends Common { public function __construct() { $this->slug = "\x61\x62\x6f\x75\164"; $this->isPrivate = false; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x41\142\x6f\x75\x74", PR__CVR__FILEFOX); } }
