<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707be02c6f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page; use Pmpr\Common\Foundation\Page\Page; abstract class Common extends Page { }
