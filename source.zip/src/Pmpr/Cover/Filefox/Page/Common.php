<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a886ed4b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page; use Pmpr\Common\Foundation\Page\Page; abstract class Common extends Page { }
