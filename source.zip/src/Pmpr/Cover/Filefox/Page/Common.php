<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a868dc559             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page; use Pmpr\Common\Foundation\Page\Page; abstract class Common extends Page { }
