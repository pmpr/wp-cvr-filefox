<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68db120fcc421             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page\Material; use Pmpr\Common\Foundation\Frontend\TaxonomyEndPoint; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends TaxonomyEndPoint { public function qiccuiwooiquycsg() { $this->ykuiyscecakwkmui(Constants::oeeqisiiqoswqqmy)->gecckeoacskeskii(__('Contact', PR__CVR__FILEFOX))->sqemekeuykmooums(); parent::qiccuiwooiquycsg(); } }
