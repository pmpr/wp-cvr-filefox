<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e598cfbd21a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page\Material; use Pmpr\Common\Foundation\Frontend\TaxonomyEndPoint; use Pmpr\Common\Foundation\Interfaces\Constants; class About extends TaxonomyEndPoint { public function qiccuiwooiquycsg() { $this->ykuiyscecakwkmui(Constants::oeeqisiiqoswqqmy)->gecckeoacskeskii(__('About', PR__CVR__FILEFOX)); parent::qiccuiwooiquycsg(); } }
