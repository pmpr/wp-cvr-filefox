<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e5a5779cc75             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page\Material; use Pmpr\Cover\Filefox\Container; class Material extends Container { public function mameiwsayuyquoeq() { Home::symcgieuakksimmu(); Store::symcgieuakksimmu(); About::symcgieuakksimmu(); Contact::symcgieuakksimmu(); } }
