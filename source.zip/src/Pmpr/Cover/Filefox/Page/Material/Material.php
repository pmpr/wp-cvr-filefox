<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6952c8c55cf88             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page\Material; use Pmpr\Cover\Filefox\Container; class Material extends Container { public function mameiwsayuyquoeq() { Home::symcgieuakksimmu(); Store::symcgieuakksimmu(); About::symcgieuakksimmu(); Contact::symcgieuakksimmu(); } }
