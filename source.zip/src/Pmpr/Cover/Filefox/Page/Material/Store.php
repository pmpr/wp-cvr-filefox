<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68db120fcc421             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page\Material; use Pmpr\Common\Foundation\Frontend\TaxonomyEndPoint; use Pmpr\Common\Foundation\Interfaces\Constants; class Store extends TaxonomyEndPoint { public function qiccuiwooiquycsg() { $this->ykuiyscecakwkmui(Constants::oeeqisiiqoswqqmy)->gecckeoacskeskii(__('Shop', PR__CVR__FILEFOX)); parent::qiccuiwooiquycsg(); } }
