<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a886ed4b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page; use Pmpr\Cover\Filefox\Container; class Page extends Container { public function mameiwsayuyquoeq() { About::symcgieuakksimmu(); } }
