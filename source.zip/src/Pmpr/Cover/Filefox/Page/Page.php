<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85b7f9cf             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page; use Pmpr\Cover\Filefox\Container; class Page extends Container { public function mameiwsayuyquoeq() { About::symcgieuakksimmu(); } }
