<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb569c6a791             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page; use Pmpr\Cover\Filefox\Container; class Page extends Container { public function mameiwsayuyquoeq() { About::symcgieuakksimmu(); } }
