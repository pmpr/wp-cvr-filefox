<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b65bd86d7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page; use Pmpr\Cover\Filefox\Container; class Page extends Container { public function mameiwsayuyquoeq() { About::symcgieuakksimmu(); } }
