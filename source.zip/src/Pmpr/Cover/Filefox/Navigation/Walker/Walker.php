<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9d4b867aca             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker as BaseClass; use Pmpr\Cover\Filefox\Traits\CommonTrait; class Walker extends baseClass { use CommonTrait; protected string $elTag = 'div'; protected string $lvlTag = 'div'; public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $siquossayskcwkea = parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); $siquossayskcwkea['rel'] = 'nofollow noopener noreferrer'; return $siquossayskcwkea; } public function yuawgssgauywkiia($ewgwqamkygiqaawc, $wwgucssaecqekuek) : string { if (empty($wwgucssaecqekuek['href']) || '#' === $wwgucssaecqekuek['href']) { unset($wwgucssaecqekuek['href'], $wwgucssaecqekuek['title'], $wwgucssaecqekuek['rel']); $swqimwqeweekeusq = $this->caokeucsksukesyo()->wgqqgewcmcemoewo(); $wwgucssaecqekuek = $swqimwqeweekeusq->igmaewykumgwoaoy($wwgucssaecqekuek, 'class', 'as-link'); return $swqimwqeweekeusq->gmqyuaqwgiayskei($ewgwqamkygiqaawc, $wwgucssaecqekuek); } return parent::yuawgssgauywkiia($ewgwqamkygiqaawc, $wwgucssaecqekuek); } }
