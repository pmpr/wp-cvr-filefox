<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b65bd86d7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker as BaseClass; use Pmpr\Cover\Filefox\Traits\CommonTrait; class Walker extends baseClass { use CommonTrait; protected string $elTag = "\x64\151\166"; protected string $lvlTag = "\144\151\x76"; }
