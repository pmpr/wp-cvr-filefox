<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e4de4360de6             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
