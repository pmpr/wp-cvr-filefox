<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680567a437cd5             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
