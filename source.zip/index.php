<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc7c19d34fe             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
