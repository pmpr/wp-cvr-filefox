<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67cf387430f32             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
