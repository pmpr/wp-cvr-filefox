<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a7249f45d12             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
