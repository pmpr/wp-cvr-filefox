<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67cecad9be7e1             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
