<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68daeb717bc06             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
