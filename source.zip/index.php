<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dbbf14d99e3             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
