<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc12edef6a             |
    |_______________________________________|
*/
 pmpr_do_action("\x69\x6e\x69\164\137\143\x6f\x76\x65\x72");
