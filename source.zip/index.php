<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68de68e28cf6e             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
