<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67e934b68f738             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
