<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbeaaf010d             |
    |_______________________________________|
*/
 require_once __DIR__ . "\57\x76\145\156\x64\x6f\x72\x2f\141\165\164\x6f\154\x6f\141\144\56\x70\x68\x70"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\160\150\160" => "\67\x2e\x32", "\167\x70" => "\65\x2e\x32", "\164\x69\164\x6c\x65" => __("\x46\151\154\145\x66\x6f\x78"), "\146\151\154\x65" => __FILE__]); if ($yqicqqkokawiosom) { if (class_exists(Filefox::class)) { $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); } } else { wp_die("\x52\145\x71\x75\151\162\145\155\145\156\164\x73\x20\144\x69\x64\40\x6e\157\x74\40\160\141\163\x73\x20\146\x6f\x72\x20\x74\x68\145\40\x63\157\166\145\x72"); }
