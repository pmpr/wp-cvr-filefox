<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a886ed4b             |
    |_______________________________________|
*/
 require_once __DIR__ . "\57\166\145\156\144\157\162\x2f\x61\165\164\x6f\154\157\x61\x64\56\160\x68\160"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\160\x68\x70" => "\67\56\62", "\x77\x70" => "\65\x2e\x32", "\164\x69\164\154\x65" => __("\106\151\154\145\146\x6f\x78"), "\146\151\x6c\x65" => __FILE__]); if ($yqicqqkokawiosom) { if (class_exists(Filefox::class)) { $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); } } else { wp_die("\122\x65\x71\165\151\162\x65\155\x65\x6e\164\x73\40\144\151\144\x20\156\x6f\x74\x20\x70\141\x73\x73\40\146\157\x72\40\164\x68\x65\40\143\x6f\166\x65\x72"); }
