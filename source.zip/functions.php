<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661da2bc3684a             |
    |_______________________________________|
*/
 require_once __DIR__ . "\x2f\166\145\156\144\157\162\57\x61\x75\x74\x6f\154\157\141\144\56\160\150\160"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\x70\x68\x70" => "\x37\56\x32", "\x77\160" => "\65\56\x32", "\164\x69\164\154\145" => __("\x46\151\x6c\x65\x66\157\x78"), "\x66\x69\x6c\145" => __FILE__]); if ($yqicqqkokawiosom) { goto qiaqsassksqiuyae; } wp_die("\122\x65\161\165\151\x72\x65\x6d\145\156\164\x73\x20\x64\151\144\40\156\157\164\40\160\x61\x73\163\x20\x66\x6f\x72\x20\164\150\145\x20\143\157\166\x65\162"); goto qogqewiwmwiwskgm; qiaqsassksqiuyae: if (!class_exists(Filefox::class)) { goto cecuyayqoioasumi; } $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); cecuyayqoioasumi: qogqewiwmwiwskgm:
