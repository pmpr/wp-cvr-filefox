<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707be02c6f             |
    |_______________________________________|
*/
 require_once __DIR__ . "\x2f\166\145\156\144\157\x72\x2f\141\x75\164\157\x6c\x6f\x61\144\x2e\160\150\x70"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\160\x68\x70" => "\x37\56\x32", "\x77\x70" => "\65\56\62", "\x74\x69\164\154\145" => __("\x46\151\154\x65\146\157\170"), "\x66\151\154\145" => __FILE__]); if ($yqicqqkokawiosom) { goto ugqaaewwmkocwwgy; } wp_die("\122\145\x71\165\151\162\145\155\145\156\164\163\x20\144\151\144\x20\x6e\x6f\164\x20\160\x61\x73\163\x20\146\x6f\x72\x20\164\150\x65\x20\x63\157\x76\x65\x72"); goto wgewmqieuamsoayy; ugqaaewwmkocwwgy: if (!class_exists(Filefox::class)) { goto omqiayeucoioqoao; } $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); omqiayeucoioqoao: wgewmqieuamsoayy:
