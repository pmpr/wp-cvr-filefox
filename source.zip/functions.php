<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf78515951             |
    |_______________________________________|
*/
 require_once __DIR__ . "\57\x76\145\156\x64\x6f\162\x2f\x61\x75\x74\157\154\x6f\141\x64\x2e\x70\150\x70"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\160\x68\x70" => "\x37\x2e\62", "\167\x70" => "\65\56\x32", "\x74\151\164\x6c\145" => __("\106\x69\x6c\x65\x66\157\170"), "\x66\151\x6c\145" => __FILE__]); if ($yqicqqkokawiosom) { goto qiaqsassksqiuyae; } wp_die("\122\145\161\x75\151\162\x65\155\145\x6e\164\x73\x20\144\151\x64\x20\x6e\x6f\x74\x20\160\x61\163\x73\x20\x66\157\162\x20\164\x68\x65\40\143\157\x76\x65\x72"); goto qogqewiwmwiwskgm; qiaqsassksqiuyae: if (!class_exists(Filefox::class)) { goto cecuyayqoioasumi; } $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); cecuyayqoioasumi: qogqewiwmwiwskgm:
