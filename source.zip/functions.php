<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b65bd86d7             |
    |_______________________________________|
*/
 use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\160\x68\160" => "\67\x2e\x32", "\167\160" => "\65\x2e\62", "\164\x69\x74\154\145" => __("\x46\151\154\145\146\157\170"), "\146\x69\x6c\x65" => __FILE__]); if ($yqicqqkokawiosom) { goto ugqaaewwmkocwwgy; } wp_die("\122\145\161\165\x69\x72\145\155\x65\x6e\x74\x73\40\144\151\x64\40\x6e\x6f\164\x20\x70\x61\163\x73\x20\x66\157\162\40\x74\150\x65\x20\143\157\166\145\162"); goto wgewmqieuamsoayy; ugqaaewwmkocwwgy: if (!class_exists(Filefox::class)) { goto omqiayeucoioqoao; } $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); omqiayeucoioqoao: wgewmqieuamsoayy:
