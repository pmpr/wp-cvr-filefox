<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85b7f9cf             |
    |_______________________________________|
*/
 require_once __DIR__ . "\x2f\x76\145\156\144\x6f\x72\x2f\x61\165\164\x6f\x6c\157\x61\x64\x2e\x70\x68\160"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\160\150\160" => "\67\56\62", "\167\x70" => "\65\x2e\x32", "\x74\x69\164\154\x65" => __("\106\x69\154\x65\x66\157\x78"), "\146\x69\x6c\x65" => __FILE__]); if ($yqicqqkokawiosom) { goto qiaqsassksqiuyae; } wp_die("\122\145\x71\x75\151\162\x65\x6d\x65\156\x74\x73\40\x64\x69\x64\40\x6e\x6f\164\40\x70\x61\x73\x73\x20\x66\157\x72\40\164\x68\x65\x20\x63\157\x76\145\x72"); goto qogqewiwmwiwskgm; qiaqsassksqiuyae: if (!class_exists(Filefox::class)) { goto cecuyayqoioasumi; } $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); cecuyayqoioasumi: qogqewiwmwiwskgm:
