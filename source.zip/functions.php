<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11456bfce             |
    |_______________________________________|
*/
 require_once __DIR__ . "\57\x76\145\156\144\157\162\x2f\x61\165\x74\157\154\x6f\141\144\56\160\x68\160"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\x70\x68\x70" => "\67\56\62", "\167\160" => "\65\56\x32", "\x74\x69\164\x6c\x65" => __("\x46\x69\154\x65\146\x6f\x78"), "\x66\151\154\x65" => __FILE__]); if ($yqicqqkokawiosom) { goto ugqaaewwmkocwwgy; } wp_die("\122\x65\161\x75\151\162\145\x6d\x65\156\164\x73\x20\144\x69\x64\x20\x6e\x6f\164\40\160\141\163\x73\40\x66\x6f\162\40\164\150\x65\x20\143\157\x76\145\x72"); goto wgewmqieuamsoayy; ugqaaewwmkocwwgy: if (!class_exists(Filefox::class)) { goto omqiayeucoioqoao; } $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); omqiayeucoioqoao: wgewmqieuamsoayy:
