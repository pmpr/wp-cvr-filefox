<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400881d567             |
    |_______________________________________|
*/
 require_once __DIR__ . "\x2f\x76\145\156\144\157\x72\57\x61\165\164\157\154\x6f\x61\x64\56\x70\150\160"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\x70\150\x70" => "\67\56\x32", "\x77\x70" => "\65\x2e\62", "\x74\151\164\154\x65" => __("\106\x69\154\x65\146\x6f\170"), "\x66\151\154\145" => __FILE__]); if ($yqicqqkokawiosom) { goto ugqaaewwmkocwwgy; } wp_die("\122\145\x71\x75\x69\x72\145\x6d\x65\156\x74\163\40\x64\x69\x64\40\156\x6f\164\40\160\141\x73\x73\x20\146\157\162\x20\164\150\x65\40\x63\x6f\x76\x65\162"); goto wgewmqieuamsoayy; ugqaaewwmkocwwgy: if (!class_exists(Filefox::class)) { goto omqiayeucoioqoao; } $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); omqiayeucoioqoao: wgewmqieuamsoayy:
