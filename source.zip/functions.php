<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678030ca66a8e             |
    |_______________________________________|
*/
 require_once __DIR__ . "\x2f\166\x65\156\144\x6f\162\57\141\x75\x74\x6f\154\157\x61\x64\56\x70\150\160"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\160\x68\160" => "\67\x2e\62", "\167\160" => "\x35\56\62", "\164\151\x74\154\145" => __("\x46\x69\x6c\x65\146\157\x78"), "\146\151\x6c\145" => __FILE__]); if ($yqicqqkokawiosom) { if (class_exists(Filefox::class)) { $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); } } else { wp_die("\122\x65\x71\x75\x69\x72\x65\x6d\x65\156\164\163\40\x64\x69\x64\x20\x6e\x6f\164\40\160\141\163\x73\40\x66\x6f\162\x20\164\150\145\40\x63\x6f\166\145\162"); }
