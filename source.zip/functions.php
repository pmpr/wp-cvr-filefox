<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc12edef6a             |
    |_______________________________________|
*/
 require_once __DIR__ . "\57\x76\145\156\x64\157\x72\57\141\165\164\x6f\x6c\x6f\x61\144\x2e\160\x68\160"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\160\x68\160" => "\67\56\62", "\x77\x70" => "\x35\x2e\x32", "\164\151\x74\x6c\145" => __("\106\151\x6c\145\x66\157\170"), "\x66\x69\x6c\x65" => __FILE__]); if ($yqicqqkokawiosom) { if (class_exists(Filefox::class)) { $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); } } else { wp_die("\122\x65\161\x75\151\162\145\x6d\x65\156\164\163\40\144\x69\144\40\156\x6f\164\x20\x70\141\x73\163\x20\x66\x6f\x72\x20\164\150\x65\40\143\157\x76\145\x72"); }
