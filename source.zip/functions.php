<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb569c6a791             |
    |_______________________________________|
*/
 require_once __DIR__ . "\57\x76\145\156\x64\157\x72\x2f\141\x75\x74\x6f\154\x6f\141\x64\56\160\150\160"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\x70\150\160" => "\x37\x2e\x32", "\x77\x70" => "\x35\56\62", "\x74\x69\x74\154\x65" => __("\106\151\x6c\145\146\157\x78"), "\x66\151\x6c\x65" => __FILE__]); if ($yqicqqkokawiosom) { goto ugqaaewwmkocwwgy; } wp_die("\x52\x65\x71\165\151\162\x65\x6d\145\156\164\163\x20\x64\x69\x64\40\156\157\164\x20\160\141\163\x73\40\146\x6f\162\40\164\x68\145\x20\x63\157\166\x65\162"); goto wgewmqieuamsoayy; ugqaaewwmkocwwgy: if (!class_exists(Filefox::class)) { goto omqiayeucoioqoao; } $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); omqiayeucoioqoao: wgewmqieuamsoayy:
