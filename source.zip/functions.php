<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebebf1b4e             |
    |_______________________________________|
*/
 require_once __DIR__ . "\57\x76\x65\156\144\x6f\162\x2f\141\165\164\x6f\x6c\157\141\144\56\160\x68\x70"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\160\150\160" => "\x37\x2e\x32", "\167\x70" => "\65\x2e\62", "\x74\x69\164\x6c\x65" => __("\x46\x69\154\145\146\157\x78"), "\x66\151\x6c\145" => __FILE__]); if ($yqicqqkokawiosom) { goto qiaqsassksqiuyae; } wp_die("\122\145\x71\165\151\x72\x65\155\x65\156\x74\x73\40\x64\x69\x64\x20\156\157\x74\x20\160\x61\163\x73\40\146\157\x72\x20\164\150\x65\x20\143\157\x76\145\x72"); goto qogqewiwmwiwskgm; qiaqsassksqiuyae: if (!class_exists(Filefox::class)) { goto cecuyayqoioasumi; } $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); cecuyayqoioasumi: qogqewiwmwiwskgm:
