<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbf4e071b1             |
    |_______________________________________|
*/
 require_once __DIR__ . "\57\166\x65\156\144\157\x72\57\x61\x75\x74\157\154\x6f\141\x64\56\x70\150\x70"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\160\150\x70" => "\x37\x2e\62", "\167\160" => "\65\x2e\x32", "\164\x69\x74\154\145" => __("\x46\151\154\145\146\157\170"), "\146\x69\x6c\145" => __FILE__]); if ($yqicqqkokawiosom) { if (class_exists(Filefox::class)) { $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); } } else { wp_die("\122\145\x71\165\151\x72\145\x6d\145\156\164\163\x20\x64\151\144\x20\x6e\157\x74\x20\160\x61\x73\163\40\x66\x6f\x72\x20\x74\150\x65\40\143\x6f\x76\145\162"); }
