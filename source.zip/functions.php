<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67915234b5a7e             |
    |_______________________________________|
*/
 require_once __DIR__ . "\57\x76\x65\156\x64\x6f\162\57\141\165\164\x6f\x6c\157\141\144\56\x70\x68\160"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\x70\x68\160" => "\x37\56\62", "\x77\160" => "\x35\56\62", "\x74\151\x74\x6c\145" => __("\106\151\154\x65\x66\x6f\x78"), "\x66\151\154\145" => __FILE__]); if ($yqicqqkokawiosom) { if (class_exists(Filefox::class)) { $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); } } else { wp_die("\122\x65\x71\x75\151\162\x65\155\x65\156\x74\163\40\x64\151\x64\x20\156\157\x74\x20\160\141\x73\x73\40\x66\157\x72\x20\164\x68\145\40\143\157\166\x65\162"); }
